package com.gdomhid.login.model.entity;

public class RowsResponse {

    public long rows;

    public RowsResponse() {
    }

    @Override
    public String toString() {
        return "EditResponse{" +
                "rows=" + rows +
                '}';
    }
}
