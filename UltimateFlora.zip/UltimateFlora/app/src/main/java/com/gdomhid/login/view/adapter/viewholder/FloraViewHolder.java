package com.gdomhid.login.view.adapter.viewholder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.gdomhid.login.R;
import com.gdomhid.login.model.entity.Flora;

public class FloraViewHolder extends RecyclerView.ViewHolder {

    public ImageView imageFlora;
    public TextView nombreFlora;
    public Flora flora;

    public FloraViewHolder(@NonNull View itemView) {
        super(itemView);
        imageFlora = itemView.findViewById(R.id.ivFlora);
        nombreFlora = itemView.findViewById(R.id.tvFlora);
    }
}
