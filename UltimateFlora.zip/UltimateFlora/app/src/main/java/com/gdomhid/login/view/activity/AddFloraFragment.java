package com.gdomhid.login.view.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.gdomhid.login.R;
import com.gdomhid.login.databinding.AddFloraBinding;
import com.gdomhid.login.model.entity.Flora;
import com.gdomhid.login.model.entity.Imagen;
import com.gdomhid.login.view.adapter.FloraAdapter;
import com.gdomhid.login.viewmodel.FloraViewModel;

import java.util.concurrent.atomic.AtomicReference;

public class AddFloraFragment extends Fragment {

    private AddFloraBinding binding;
    private FloraViewModel fvm;
    private Uri urlimg;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = AddFloraBinding.inflate(inflater, container, false);
        initialize();
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    private void initialize() {
        Bundle datos = this.getArguments();
        AtomicReference<String> u = new AtomicReference<>("");
        ActivityResultLauncher<String> mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(),
                uri -> {
                    // Handle the returned Uri
                    Glide.with(getActivity()).load(uri).into(binding.imageFlora);
                    u.set(String.valueOf(uri));
                    urlimg = uri;
                });
        binding.imageFlora.setOnClickListener(view -> {
            // Pass in the mime type you'd like to allow the user to select
            // as the input
            mGetContent.launch("image/*");
        });
        fvm = new ViewModelProvider(this).get(FloraViewModel.class);

        if (datos != null) {
            binding.bAddFlora.setVisibility(View.INVISIBLE);
            Flora f = datos.getParcelable("flora");
            setFlora(f);
            updateFloraListener(u, f);
            deleteFloraListener(f);
        } else {
            binding.bEditFlora.setVisibility(View.INVISIBLE);
            binding.bDeleteFlora.setVisibility(View.INVISIBLE);
            defineAddListener(u);
        }
    }
    private void setFlora(Flora f) {
        Glide.with(getActivity()).load("https://informatica.ieszaidinvergeles.org:10005/ad/felixApp/public/api/imagen/"+f.getId()+"/flora").into(binding.imageFlora);
        binding.etAltitud.setText(f.getAltitud());
        binding.etAmenazas.setText(f.getAmenazas());
        binding.etBiologia.setText(f.getBiologia());
        binding.etBiotipo.setText(f.getBiotipo());
        binding.etDemografia.setText(f.getDemografia());
        binding.etBiologiaReproductiva.setText(f.getBiologia_reproductiva());
        binding.etDispersion.setText(f.getDispersion());
        binding.etDistribucion.setText(f.getDistribucion());
        binding.etExpresionSexual.setText(f.getExpresion_sexual());
        binding.etFamilia.setText(f.getFamilia());
        binding.etFitosociologia.setText(f.getFitosociologia());
        binding.etFloracion.setText(f.getFloracion());
        binding.etFructificacion.setText(f.getFructificacion());
        binding.etHabitat.setText(f.getHabitat());
        binding.etIdentificacion.setText(f.getIdentificacion());
        binding.etMedidasPropuestas.setText(f.getMedidas_propuestas());
        binding.etNombre.setText(f.getNombre());
        binding.etNumeroCromosomatico.setText(f.getNumero_cromosomatico());
        binding.etPolinizacion.setText(f.getPolinizacion());
        binding.etReproduccionAsexual.setText(f.getReproduccion_asexual());
    }

    private void updateFloraListener(AtomicReference<String> u, Flora f) {
        binding.bEditFlora.setOnClickListener(v -> {
            Flora ff = getFlora(u);
            fvm.editFlora(f.getId(), ff);
            Imagen i = getImagen(f);//creo un objeto imagen
            fvm.saveImagen(urlimg, i);//subo la imagen
            NavHostFragment.findNavController(AddFloraFragment.this)
                    .navigate(R.id.action_addFragment_to_SecondFragment);
        });
    }

    private Flora getFlora(AtomicReference<String> u) {
        Flora f = new Flora();
        f.setAltitud(String.valueOf(binding.etAltitud.getText()));
        f.setAmenazas(String.valueOf(binding.etAmenazas.getText()));
        f.setBiologia(String.valueOf(binding.etBiologia.getText()));
        f.setBiotipo(String.valueOf(binding.etBiotipo.getText()));
        f.setDemografia(String.valueOf(binding.etDemografia.getText()));
        f.setBiologia_reproductiva(String.valueOf(binding.etBiologiaReproductiva.getText()));
        f.setDispersion(String.valueOf(binding.etDispersion.getText()));
        f.setDistribucion(String.valueOf(binding.etDistribucion.getText()));
        f.setExpresion_sexual(String.valueOf(binding.etExpresionSexual.getText()));
        f.setFamilia(String.valueOf(binding.etFamilia.getText()));
        f.setFitosociologia(String.valueOf( binding.etFitosociologia.getText()));
        f.setFloracion(String.valueOf(binding.etFloracion.getText()));
        f.setFructificacion(String.valueOf(binding.etFructificacion.getText()));
        f.setHabitat(String.valueOf(binding.etHabitat.getText()));
        f.setIdentificacion(String.valueOf(binding.etIdentificacion.getText()));
        f.setMedidas_propuestas(String.valueOf(binding.etMedidasPropuestas.getText()));
        f.setNombre(String.valueOf(binding.etNombre.getText()));
        f.setNumero_cromosomatico(String.valueOf(binding.etNumeroCromosomatico.getText()));
        f.setPolinizacion(String.valueOf(binding.etPolinizacion.getText()));
        f.setReproduccion_asexual(String.valueOf(binding.etReproduccionAsexual.getText()));
        return f;
    }
    private Imagen getImagen(Flora f){
        Imagen i = new Imagen();
        i.idflora = f.getId();
        i.nombre = f.getNombre();
        return i;
    }
    private void deleteFloraListener(Flora f) {
        binding.bDeleteFlora.setOnClickListener(v -> {
            showRationaleDialog("Delete flora", "Are you sure to want to delete this flora?", f);
        });
    }
    private void showRationaleDialog(String title, String message, Flora f) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title)
                .setMessage(message)
                .setNegativeButton(android.R.string.cancel, (dialogInterface, i) -> {
                    // Si pulso negativo no quiero hacer nada
                })
                .setPositiveButton(android.R.string.ok, (dialogInterface, i) -> {
                    fvm.deleteFlora(f.getId());
                    NavHostFragment.findNavController(AddFloraFragment.this)
                            .navigate(R.id.action_addFragment_to_SecondFragment);
                });
        builder.create().show();
    }

    private void defineAddListener(AtomicReference<String> u) {
        binding.bAddFlora.setOnClickListener(v -> {
            Flora f = getFlora(u);//Obtengo la flora de todos los campos
            fvm.createFlora(f);//Creo la flora pero NO TIENE ID
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            FloraViewModel mavm = new ViewModelProvider(this).get(FloraViewModel.class);
            mavm.getFloraLiveData().observe(getViewLifecycleOwner(), floraPlural -> {
                Log.v("xyzyx", "FlORita " + floraPlural.get(floraPlural.size() - 1).getId());
                //Obtengo todas las floras en floraPlural
                Imagen i = getImagen(f);//creo un objeto imagen
                i.idflora = floraPlural.get(floraPlural.size() - 1).getId();//Le asigno el id de la imagen a la nueva flora
                Log.v("xyzyx", "IDFLORAimage   " + i.idflora);
                fvm.saveImagen(urlimg, i);//subo la imagen
            });
            mavm.getFlora();//TACHAAAN
            try {
                Thread.sleep(1000);
                NavHostFragment.findNavController(AddFloraFragment.this)
                        .navigate(R.id.action_addFragment_to_SecondFragment);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        });
    }


    /*private void getViewModel() {
        dvm = new ViewModelProvider(this).get(DogViewModel.class);
        bvm = new ViewModelProvider(this).get(BreedViewModel.class);

        bvm.getBreeds().observe(getActivity(), breeds -> {
            Breed breed = new Breed();
            breed.breedId = 0;
            breed.breedName = getString(R.string.default_breed);
            breeds.add(0, breed);
            ArrayAdapter<Breed> adapter =
                    new ArrayAdapter<Breed>(getActivity().getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, breeds);
            BreedsSpinner.setAdapter(adapter);
        });
    }*/

    /*private void defineAddListener(AtomicReference<String> u) {
        binding.bAddDog.setOnClickListener(v -> {
            Dog dog = getDog(u);
            dvm.insertDog(dog);
            NavHostFragment.findNavController(AddFragment.this)
                    .navigate(R.id.action_addFragment_to_SecondFragment);
        });
    }

    private void updateDogListener(AtomicReference<String> u, Dog d) {
        binding.bEditDog.setVisibility(View.VISIBLE);
        binding.bAddDog.setVisibility(View.GONE);
        binding.bEditDog.setOnClickListener(v -> {
            Dog dog = getDog(u);
            dog.dogId = d.dogId;
            if (dog.dogImage == null) {
                dog.dogImage = d.dogImage;
            }
            dvm.updateDog(dog);
            NavHostFragment.findNavController(AddFragment.this)
                    .navigate(R.id.action_addFragment_to_SecondFragment);
        });
    }

    private void deleteFloraListener(Flora f) {
        binding.bDeleteDog.setVisibility(View.VISIBLE);
        binding.bDeleteDog.setOnClickListener(v -> {
            showRationaleDialog("Delete dog", "Are you sure to want to delete a dog?", d);
        });
    }

    private Dog getDog(AtomicReference<String> u) {
        Dog dog = new Dog();
        dog.userId = 1;
        dog.dogName = binding.tipDogName.getEditText().getText().toString();
        dog.dogWeight = Integer.parseInt(binding.tipDogWeight.getEditText().getText().toString());
        dog.dogImage = String.valueOf(u);
        dog.dogGender = binding.rgGender.getCheckedRadioButtonId();
        dog.dogBirthday = binding.cvBirthday.getDate();
        dog.dogOtherInformation = binding.tipOtherInfo.getEditText().getText().toString();
        return dog;
    }

    private void setDog(Dog dog) {
        dog.userId = 1;
        binding.tipDogName.getEditText().setText(dog.dogName);
        binding.tipDogWeight.getEditText().setText(String.valueOf(dog.dogWeight));
        Glide.with(getActivity()).load(dog.dogImage).into(binding.ivDog);
        binding.cvBirthday.setDate(dog.dogBirthday);
        binding.tipOtherInfo.getEditText().setText(dog.dogOtherInformation);
        binding.cvBirthday.setDate(dog.dogBirthday);
    }

    private void showRationaleDialog(String title, String message, Dog d) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title)
                .setMessage(message)
                .setNegativeButton(android.R.string.cancel, (dialogInterface, i) -> {
                    // Si pulso negativo no quiero hacer nada
                })
                .setPositiveButton(android.R.string.ok, (dialogInterface, i) -> {
                    dvm.deleteDog(d);
                    NavHostFragment.findNavController(AddFragment.this)
                            .navigate(R.id.action_addFragment_to_SecondFragment);
                });
        builder.create().show();
    }*/
}