package com.gdomhid.login.view.adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.gdomhid.login.R;
import com.gdomhid.login.model.entity.Flora;
import com.gdomhid.login.view.adapter.viewholder.FloraViewHolder;

import java.util.List;

public class FloraAdapter extends RecyclerView.Adapter<FloraViewHolder> {

    private Context context;
    private List<Flora> floras;

    public FloraAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public FloraViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_flora, parent, false);
        return new FloraViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FloraViewHolder holder, int position) {
        Flora f = floras.get(position);
        holder.flora = f;
        holder.nombreFlora.setText(f.getNombre());
        Glide.with(context).load("https://informatica.ieszaidinvergeles.org:10005/ad/felixApp/public/api/imagen/"+f.getId()+"/flora").diskCacheStrategy(DiskCacheStrategy.NONE)
            .skipMemoryCache(true).into(holder.imageFlora);
        holder.itemView.setOnClickListener(view -> {
            Bundle bundle = new Bundle();
            bundle.putParcelable("flora", f);
            Navigation.findNavController(view).navigate(R.id.action_SecondFragment_to_addFragment, bundle);
        });
    }

    @Override
    public int getItemCount() {
        if (floras == null) {
            return 0;
        }
        return floras.size();
    }

    public void setFlorasList(List<Flora> floraList) {
        this.floras = floraList;
        notifyDataSetChanged();
    }
}
