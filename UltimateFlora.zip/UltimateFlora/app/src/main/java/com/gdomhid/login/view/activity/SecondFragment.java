package com.gdomhid.login.view.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.gdomhid.login.R;
import com.gdomhid.login.databinding.FragmentSecondBinding;
import com.gdomhid.login.view.adapter.FloraAdapter;
import com.gdomhid.login.viewmodel.FloraViewModel;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        initialize();
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.fabAddButton.setOnClickListener(view1 -> {
            NavHostFragment.findNavController(SecondFragment.this)
                    .navigate(R.id.action_SecondFragment_to_addFragment);
        });
    }

    private void initialize() {
        FloraViewModel mavm = new ViewModelProvider(this).get(FloraViewModel.class);
        mavm.getFloraLiveData().observe(getViewLifecycleOwner(), floraPlural -> {
            Log.v("xyzyx", "FlORASSS " + floraPlural.toString());

            RecyclerView rvFlora = binding.rvFloras;
            rvFlora.setLayoutManager(new GridLayoutManager(getActivity(), 2));
            FloraAdapter fa = new FloraAdapter(getActivity());
            rvFlora.setAdapter(fa);
            fa.setFlorasList(floraPlural);
        });
        mavm.getFlora();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}