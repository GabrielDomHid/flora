package com.gdomhid.login.model.entity;

public class Imagen {

    public long idflora;
    public String nombre,descripcion;

    @Override
    public String toString() {
        return "Imagen{" +
                "idflora=" + idflora +
                ", nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }
}
