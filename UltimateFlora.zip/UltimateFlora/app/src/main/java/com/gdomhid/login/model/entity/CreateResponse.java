package com.gdomhid.login.model.entity;

public class CreateResponse {

    public long id;

    public CreateResponse() {
    }

    @Override
    public String toString() {
        return "CreateResponse{" +
                "id=" + id +
                '}';
    }
}
